import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import {
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  setLogLevel,
} from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// Désactive les journaux console.error internes de @firebase/firestore lors du basculement automatique en mode Offline-First
setLogLevel('silent');

export const REQUIRED_FIREBASE_PROJECT_ID = 'ets-amani';
export const REQUIRED_PROJECT_NUMBER = '697171148070';
export const REQUIRED_STORAGE_BUCKET = 'ets-amani.firebasestorage.app';

export const firebaseConfig = {
  apiKey:
    import.meta.env.VITE_FIREBASE_API_KEY ||
    'AIzaSyBkcvmGF_-0LCbUh1cPXEO50JrYi4Jk1TA',
  authDomain:
    import.meta.env.VITE_FIREBASE_AUTH_DOMAIN ||
    'ets-amani.firebaseapp.com',
  projectId:
    import.meta.env.VITE_FIREBASE_PROJECT_ID ||
    REQUIRED_FIREBASE_PROJECT_ID,
  storageBucket:
    import.meta.env.VITE_FIREBASE_STORAGE_BUCKET ||
    REQUIRED_STORAGE_BUCKET,
  messagingSenderId:
    import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID ||
    REQUIRED_PROJECT_NUMBER,
  appId:
    import.meta.env.VITE_FIREBASE_APP_ID ||
    '1:697171148070:web:bd1150821e623991ad55e7',
};

// Contrôle strict du projet Firebase officiel : interdiction de projets tiers ou fantômes
if (firebaseConfig.projectId !== REQUIRED_FIREBASE_PROJECT_ID) {
  const errorMsg = `[Ets AMANI] ALERTE DE CONFIGURATION : Le projet Firebase configuré ('${firebaseConfig.projectId}') ne correspond pas au projet officiel requis ('${REQUIRED_FIREBASE_PROJECT_ID}').`;
  console.error(errorMsg);
  throw new Error(errorMsg);
}

export const isFirebaseConfigured = Boolean(
  firebaseConfig.apiKey && firebaseConfig.projectId
);

// Initialisation unique du singleton Firebase App
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Service d'Authentification Firebase
export const auth = getAuth(app);

// Service Firestore avec persistance locale IndexedDB multi-onglets active et détection automatique du long-polling
export const firestore = initializeFirestore(app, {
  localCache: persistentLocalCache({
    tabManager: persistentMultipleTabManager(),
  }),
  experimentalAutoDetectLongPolling: true,
});

// Service Cloud Storage officiel
export const storage = getStorage(app);

/**
 * Aliases de compatibilité pour Firestore (modules UI, services métiers et workers)
 */
export const firestoreDb = firestore;
export const db = firestore;

export default app;
